abstract public class Shapes{
	abstract double sArea();
	abstract double vol();
}
