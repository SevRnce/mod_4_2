
public class Cylinder extends Shapes{
	double radius;
	double height;
	
	Cylinder(double rad, double hgt){
		radius = rad;
		height = hgt;
	}
	
	@Override
	double sArea() {
		// area formula
		return (2*Math.PI*radius*height)+(2*Math.PI*Math.pow(radius, 2));
	}

	@Override
	double vol() {
		// volume formula
		return Math.PI*Math.pow(radius, 2)*height;
	}
	
	public String toString() {
		String outPut = "";
		outPut = outPut + "Cylinder Surface Area: " + sArea()+ "\n";
		outPut = outPut + "Cylinder Volume: " + vol()+ "\n";
		return outPut;
	}
}
