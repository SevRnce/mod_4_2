
public class Cone extends Shapes{
	double radius;
	double height;
	
	Cone(double rad, double hgt){
		radius = rad;
		height = hgt;
	}
	
	@Override
	double sArea() {
		// area formula
		return (Math.PI*radius)*(radius+(Math.sqrt(Math.pow(height, 2)*Math.pow(radius, 2))));
	}

	@Override
	double vol() {
		// volume formula
		return (Math.PI*Math.pow(radius, 2))*(height/3);
	}
	public String toString() {
		String outPut = "";
		outPut = outPut + "Cone Surface Area: " + sArea()+ "\n";
		outPut = outPut + "Cone Volume: " + vol()+ "\n";
		return outPut;
	}
}
