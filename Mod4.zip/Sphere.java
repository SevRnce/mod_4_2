
public class Sphere extends Shapes{
	double radius;
	
	Sphere(double rad){
		radius = rad;
	}

	@Override
	double sArea() {
		// area formula
		return 4*Math.PI*Math.pow(radius, 2);
	}

	@Override
	double vol() {
		// volume formula
		return (4/3)*Math.PI*Math.pow(radius, 2);
	}
	
	public String toString() {
		String outPut = "";
		outPut = outPut + "Sphere Surface Area: " + sArea()+ "\n";
		outPut = outPut + "Sphere Volume: " + vol()+ "\n";
		return outPut;
	}
}
