import java.util.Scanner;

public class ShapeArray {
	public static void main(String[]args) {
		double rad;
		double hgt;
		
		//start scanner
		Scanner scan = new Scanner(System.in);
		
		Shapes[]shapeArray = new Shapes[3];
		
		//make sphere
		System.out.println("\nEnter Radius of Sphere: ");
		rad = scan.nextDouble();
		Sphere sphere = new Sphere(rad);
		shapeArray[0] = sphere;
		
		//make cylinder
		System.out.println("\nEnter Radius of Cylinder: ");
		rad = scan.nextDouble();
		System.out.println("\nEnter Height of Cylinder: ");
		hgt = scan.nextDouble();
		Cylinder cylinder = new Cylinder(rad,hgt);
		shapeArray[1] = cylinder;
		
		//make cone
		System.out.println("\nEnter Radius of Cone: ");
		rad = scan.nextDouble();
		System.out.println("\nEnter Height of Cone: ");
		hgt = scan.nextDouble();
		Cone cone = new Cone(rad,hgt);
		shapeArray[2] = cone;
		
		//short list, no need for loops
		System.out.println(shapeArray[0]);
		System.out.println(shapeArray[1]);
		System.out.println(shapeArray[2]);
		
		scan.close();
	}
}
